class Routes {
  // static const splash = '/';
  // static const getStarted = '/getStarted';
  // static const login = '/login';
  // static const signUp = '/signUp';
  // static const forgotPassword = '/forgotPassword';
  //
  // static const changePassword = '/changePassword';
  //
  //
  static const dashboard = '/';
  static const login = '/login';
  static const home = '/home';
  static const market = '/market';
  static const plan = '/plan';
  static const profile = '/profile';

}
