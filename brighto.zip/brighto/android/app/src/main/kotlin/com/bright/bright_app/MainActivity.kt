package com.bright.bright_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
